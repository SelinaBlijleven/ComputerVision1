%% main function 

% To run these functions the files with all the images have to be stored in data.

%% fine-tune cnn

[net, info, expdir] = finetune_cnn();

%% extract features and train svm

% TODO: Replace the name with the name of your fine-tuned model
nets.fine_tuned = load(fullfile('data', 'cnn_assignment-lenet-100-100-0.000200','net-epoch-100.mat')); 
nets.fine_tuned = nets.fine_tuned.net;
% vl_simplenn_display(nets.fine_tuned)
nets.pre_trained = load(fullfile('data', 'pre_trained_model.mat'));
nets.pre_trained = nets.pre_trained.net; 
data = importdata(fullfile('data', 'cnn_assignment-lenet-100-100-0.000200', 'imdb-caltech.mat'));

%%
% train_svm(nets, data);

set.labels = [];
set.features = [];
nets.fine_tuned.layers{end}.type = 'softmax';
for i = 1:size(data.images.data, 4)
    
    res = vl_simplenn(nets.fine_tuned, data.images.data(:, :,:, i));
    feat = res(end-3).x; feat = squeeze(feat); 
    set.features = [set.features feat];
    set.labels   = [set.labels  data.images.labels(i)];
end
size(set.features)
size(set.labels)

% Set parameters
no_dims = 2;
initial_dims = 64;
perplexity = 30;
% Run t?SNE
mappedX = tsne(set.features', set.labels', no_dims, initial_dims, perplexity);
% Plot results
gscatter(mappedX(:,1), mappedX(:,2), set.labels');
